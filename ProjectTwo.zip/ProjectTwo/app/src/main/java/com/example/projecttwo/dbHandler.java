package com.example.projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.ArrayList;

public class dbHandler extends SQLiteOpenHelper {




    private static String DB_NAME = "invyDB";

    private static int DB_VERSION = 1;

    /********************************************************************
     *            Login Data Table Variables
     * ******************************************************************/

    private static String ID_COL = "id";

    private static String TABLE_NAME = "loginInfo";

    private static String EMAIL_COL = "email";

    private static String PASSWORD_COL = "password";

    /********************************************************************
     *            Inventory Data Table Variables
     * ******************************************************************/

    private static String ID_INV_COL = "id";

    private static String TABLE_NAME_INV = "inventory";

    private static String ITEM_COL = "item";

    private static String QTY_COL = "qty";



    public dbHandler(Context context){
        super(context, DB_NAME, null, DB_VERSION);
    }




    @Override
    public void onCreate(SQLiteDatabase db){

        String  sql;

        sql ="CREATE TABLE " + TABLE_NAME + " (" +
                ID_COL +" INTEGER PRIMARY KEY AUTOINCREMENT, " +
                EMAIL_COL + " TEXT," +
                PASSWORD_COL + " TEXT)";

        db.execSQL(sql);

        sql= "";

        sql = "CREATE TABLE " + TABLE_NAME_INV + " (" +
                ID_INV_COL +" INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ITEM_COL + " TEXT," +
                QTY_COL + " INT)";

        // at last we are calling a exec sql
        // method to execute above sql query

    }

    public void addUser(String emailInput, String passwordInput){

        // on below line we are creating a variable for
        // our sqlite database and calling writable method
        // as we are writing data in our database.



        SQLiteDatabase db = this.getWritableDatabase();

        // on below line we are creating a
        // variable for content values.
        ContentValues values = new ContentValues();

        // on below line we are passing all values
        // along with its key and value pair.
        values.put(EMAIL_COL, emailInput);
        values.put(PASSWORD_COL, passwordInput);

        // after adding all values we are passing
        // content values to our table.
        db.insert(TABLE_NAME, null, values);

        // at last we are closing our
        // database after adding database.
        db.close();
    }

    public Boolean checkEmail(String email){

        SQLiteDatabase readDB = this.getReadableDatabase();
        Cursor cursor = readDB.rawQuery("SELECT * FROM loginInfo where email = ?", new String[] {email});

        if(cursor.getCount() > 0){
            return true;
        }
        else{
            return false;
        }
    }
    public Boolean checkEmailAndPass(String email, String password){
        Boolean emailExists = checkEmail(email);
        if (emailExists == false){
            return false;
        }
        SQLiteDatabase readDB = this.getReadableDatabase();
        Cursor cursor = readDB.rawQuery("SELECT * FROM loginInfo where email = ? and password = ?", new String[] {email, password});

        if(cursor.getCount() > 0){
            return true;
        }
        else{
            return false;
        }

    }




    // we have created a new method for reading all the courses.
    public ArrayList<InvListItem> readCourses()
    {
        // on below line we are creating a
        // database for reading our database.
        SQLiteDatabase db = this.getReadableDatabase();

        // on below line we are creating a cursor with query to
        // read data from database.
        Cursor cursorItems
                = db.rawQuery("SELECT * FROM " + TABLE_NAME_INV, null);

        // on below line we are creating a new array list.
        ArrayList<InvListItem> courseModalArrayList
                = new ArrayList<>();

        // moving our cursor to first position.
        if (cursorItems.moveToFirst()) {
            do {
                // on below line we are adding the data from
                // cursor to our array list.
                courseModalArrayList.add(new InvListItem(
                        cursorItems.getString(1),
                        cursorItems.getInt(2)));
            } while (cursorItems.moveToNext());
            // moving our cursor to next.
        }
        // at last closing our cursor
        // and returning our array list.
        cursorItems.close();
        return courseModalArrayList;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVer, int newVer){
        db.execSQL("DROP TABLE IF EXISTS "+ TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS "+ TABLE_NAME_INV);
        onCreate(db);
    }

}
