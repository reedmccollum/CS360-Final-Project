package com.example.projecttwo;

public class InvListItem {

    private String itemName;
    private int id, qty;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public InvListItem(String itemName, int qty){
        this.itemName = itemName;
        this.qty = qty;
    }

}
