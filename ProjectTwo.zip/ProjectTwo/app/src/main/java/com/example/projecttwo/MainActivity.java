package com.example.projecttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.opengl.GLDebugHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText emailTxt;
    private EditText passTxt;
    private Button addUserBtn,loginBtn;
    private dbHandler DBHandler;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        emailTxt = findViewById(R.id.email);
        passTxt = findViewById(R.id.password);
        addUserBtn = findViewById(R.id.createaccbtn);
        loginBtn = findViewById(R.id.loginbtn);

        DBHandler = new dbHandler(MainActivity.this);

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String emailStr = emailTxt.getText().toString();
                String passStr = passTxt.getText().toString();

                if(emailStr.isEmpty() || passStr.isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter both a username and password", Toast.LENGTH_SHORT).show();
                    return;
                }
                Boolean tryCreds = DBHandler.checkEmailAndPass(emailStr, passStr);

                if(!tryCreds){
                    Toast.makeText(MainActivity.this, "The email/password credentials were not correct, please try again", Toast.LENGTH_SHORT).show();
                    return;
                }
                else{
                    Toast.makeText(MainActivity.this, "Login Successful! Welcome User!", Toast.LENGTH_SHORT).show();
                    Intent signin = new Intent(MainActivity.this, GridLayout.class);
                    startActivity(signin);
                }

            }
        });

        addUserBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String emailStr = emailTxt.getText().toString();
                String passStr = passTxt.getText().toString();

                if(emailStr.isEmpty() || passStr.isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter both a username and password", Toast.LENGTH_SHORT).show();
                    return;
                }

                DBHandler.addUser(emailStr, passStr);
                Toast.makeText(MainActivity.this, "Course has been added.", Toast.LENGTH_SHORT).show();
                passTxt.setText("");
                emailTxt.setText("");

            }
        });


    }
}